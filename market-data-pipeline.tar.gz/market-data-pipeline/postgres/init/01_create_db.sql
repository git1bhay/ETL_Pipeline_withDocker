-- Run automatically when Postgres container starts for the first time
CREATE DATABASE market_data_db;
