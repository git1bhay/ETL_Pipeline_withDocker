import random
import time
from datetime import datetime, timezone

from fastapi import FastAPI, Response

app = FastAPI(title="Mock Market Data API")

INSTRUMENTS = ["AAPL", "BTC-USD", "ETH-USD", "MSFT", "GOOGL", "TSLA", "AMZN", "NVDA"]

BASE_PRICES = {
    "AAPL": 185.0,
    "BTC-USD": 65000.0,
    "ETH-USD": 3200.0,
    "MSFT": 420.0,
    "GOOGL": 175.0,
    "TSLA": 250.0,
    "AMZN": 190.0,
    "NVDA": 900.0,
}


def generate_market_data():
    records = []
    for instrument in INSTRUMENTS:
        base = BASE_PRICES[instrument]
        price = round(base * (1 + random.uniform(-0.05, 0.05)), 4)
        volume = round(random.uniform(100, 50000), 2)
        timestamp = datetime.now(timezone.utc).isoformat()
        records.append({
            "instrument_id": instrument,
            "price": price,
            "volume": volume,
            "timestamp": timestamp,
        })
    return records


def inject_fault(records):
    """Randomly corrupt one record for chaos engineering."""
    fault_type = random.choice(["string_price", "null_volume", "missing_field"])
    idx = random.randint(0, len(records) - 1)
    if fault_type == "string_price":
        records[idx]["price"] = "NOT_A_NUMBER"
    elif fault_type == "null_volume":
        records[idx]["volume"] = None
    elif fault_type == "missing_field":
        records[idx].pop("instrument_id", None)
    return records


@app.get("/v1/market-data")
def get_market_data(response: Response):
    roll = random.random()

    # 5% chance of fault injection
    if roll < 0.025:
        response.status_code = 500
        return {"error": "Internal Server Error", "detail": "Simulated upstream failure"}

    records = generate_market_data()

    if roll < 0.05:
        records = inject_fault(records)

    return records


@app.get("/health")
def health():
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}
