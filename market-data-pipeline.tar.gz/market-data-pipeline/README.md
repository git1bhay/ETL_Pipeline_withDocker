# Market Data Pipeline

An end-to-end data engineering project: a **Mock API → ETL Pipeline → PostgreSQL** stack, fully containerised with Docker Compose.

---

## Project Structure

```
market-data-pipeline/
├── api/
│   ├── main.py            # FastAPI mock market-data server
│   ├── requirements.txt
│   └── Dockerfile
├── etl/
│   ├── pipeline.py        # Main ETL loop
│   ├── models.py          # Pydantic validation models
│   ├── db.py              # PostgreSQL helpers
│   ├── requirements.txt
│   └── Dockerfile
├── postgres/
│   └── init/
│       └── 01_create_db.sql
├── .env                   # Secret config (do not commit)
├── .gitignore
├── docker-compose.yml
└── README.md
```

---

## Quick Start

### Prerequisites
- Docker ≥ 24
- Docker Compose ≥ 2.x

### Run the whole stack

```bash
git clone <your-repo-url>
cd market-data-pipeline

# (Optional) Edit .env to change DB credentials
docker-compose up --build
```

All three services start automatically:

| Service    | URL / Port              |
|------------|-------------------------|
| API        | http://localhost:8000   |
| API Docs   | http://localhost:8000/docs |
| PostgreSQL | localhost:5432          |

### Stop the stack

```bash
docker-compose down          # stop containers
docker-compose down -v       # stop + wipe the DB volume
```

---

## API Reference

| Endpoint            | Method | Description                          |
|---------------------|--------|--------------------------------------|
| `/v1/market-data`   | GET    | Returns JSON list of market records  |
| `/health`           | GET    | Health check (`{"status": "ok"}`)    |
| `/docs`             | GET    | Swagger UI                           |

**Sample record:**
```json
{
  "instrument_id": "AAPL",
  "price": 187.34,
  "volume": 12043.5,
  "timestamp": "2024-06-01T10:00:00+00:00"
}
```

**Chaos Engineering:** 5% of requests will either return HTTP 500 or malformed data (string in a numeric field, null volume, missing field). The ETL handles this gracefully.

---

## ETL Pipeline

The ETL service polls the API every 10 seconds (configurable via `POLL_INTERVAL_SECONDS`).

### Stages

1. **Extraction** — Fetches from the API with retry logic (up to 3 attempts, configurable). Handles HTTP 500s and timeouts without crashing.

2. **Validation** — Each record is parsed through a Pydantic `MarketRecord` model. Invalid records are logged and dropped.

3. **Transformation**
   - **VWAP** = `Σ(price × volume) / Σ(volume)` per `instrument_id` in the batch.
   - **Outlier flag** = any record where `|price − avg_price| / avg_price > 15%`.

4. **Load** — Upserts into PostgreSQL with `ON CONFLICT (instrument_id, timestamp) DO NOTHING` to ensure idempotency.

### Structured Log Output

```
2024-06-01T10:00:05 [INFO] Run complete | fetched=8 valid=7 dropped=1 written=6 time=43ms
2024-06-01T10:00:05 [WARNING] Validation failure — dropped record: {...} | reason: ...
2024-06-01T10:00:05 [WARNING] Outlier detected — BTC-USD price=68500.0 avg=65000.0 deviation=5.4%
```

### Database Tables

**`market_data`**

| Column         | Type        | Notes                              |
|----------------|-------------|------------------------------------|
| `id`           | SERIAL PK   |                                    |
| `instrument_id`| TEXT        |                                    |
| `price`        | NUMERIC     |                                    |
| `volume`       | NUMERIC     |                                    |
| `timestamp`    | TIMESTAMPTZ |                                    |
| `vwap`         | NUMERIC     | Batch VWAP                         |
| `is_outlier`   | BOOLEAN     | Flagged if >15% deviation          |
| `ingested_at`  | TIMESTAMPTZ | Auto-set on insert                 |
| UNIQUE         |             | `(instrument_id, timestamp)`       |

**`pipeline_runs`** — one row per ETL execution with counts and timing.

---

## Environment Variables

| Variable                | Default                           | Description                    |
|-------------------------|-----------------------------------|--------------------------------|
| `DB_HOST`               | `postgres`                        | PostgreSQL host                |
| `DB_PORT`               | `5432`                            | PostgreSQL port                |
| `DB_NAME`               | `market_data_db`                  | Database name                  |
| `DB_USER`               | `market_user`                     | DB username                    |
| `DB_PASSWORD`           | `market_secret_123`               | DB password                    |
| `API_URL`               | `http://api:8000/v1/market-data`  | Market data endpoint           |
| `POLL_INTERVAL_SECONDS` | `10`                              | ETL polling frequency          |
| `OUTLIER_THRESHOLD`     | `0.15`                            | Outlier detection threshold    |
| `REQUEST_TIMEOUT_SECONDS` | `5`                             | HTTP request timeout           |
| `MAX_RETRIES`           | `3`                               | Fetch retry count              |

---

## System Design Q&A

### 1. Scaling to 1 Billion Events/Day

At ~11,500 events/second the current synchronous polling model would become a bottleneck. The architecture would evolve in layers:

**Ingest layer — Apache Kafka**
Replace direct API polling with a Kafka producer. Multiple consumer groups can read the same topic independently, giving horizontal scalability and replay capability. Kafka retains messages, so a slow consumer doesn't lose data.

**Processing layer — Apache Spark (or Flink)**
Replace the Python ETL script with a Spark Structured Streaming job. Spark can fan out across a cluster, compute VWAP and outlier detection on micro-batches in parallel, and write results to the sink at scale. For sub-second latency, Apache Flink is preferable.

**Storage layer — partitioned columnar store**
Replace plain PostgreSQL with a combination:
- **OLTP writes**: PostgreSQL or CockroachDB for recent/hot data.
- **OLAP queries**: Apache Iceberg or Delta Lake on object storage (S3/GCS) for historical analysis. Partition by `date` + `instrument_id`.

**Orchestration**: Apache Airflow or Prefect for scheduling and dependency management. Cloud-native alternative: AWS Kinesis + AWS Glue + Redshift.

---

### 2. Production Health Checks & Monitoring

Three layers of observability:

**Infrastructure health**
- Docker/Kubernetes liveness and readiness probes already defined in `docker-compose.yml`.
- Kubernetes `livenessProbe` restarts a crashed container; `readinessProbe` removes it from load balancing until ready.

**Pipeline metrics (Prometheus + Grafana)**
Instrument the ETL to expose a `/metrics` endpoint with counters:
- `pipeline_records_processed_total`
- `pipeline_records_dropped_total`
- `pipeline_run_duration_seconds`
- `pipeline_last_success_timestamp` — alert if this goes stale (heartbeat monitor).

**Alerting rules (PagerDuty / Alertmanager)**
- `drop_rate > 10%` for 5 minutes → warning.
- `no successful run in 60s` → critical.
- `DB write latency p99 > 500ms` → warning.

**Data quality monitoring (Great Expectations / dbt tests)**
Run expectation suites after each batch: `price > 0`, `volume > 0`, `no nulls in instrument_id`, `row count in expected range`.

---

### 3. Idempotency & Recovery from Mid-Batch Failures

**Idempotency at the DB level**
The `UNIQUE (instrument_id, timestamp)` constraint plus `ON CONFLICT DO NOTHING` means re-running the same batch never creates duplicates. Any restart simply re-inserts and skips already-present rows.

**Checkpoint pattern for large batches**
For a 10 GB batch:
1. Split the batch into fixed-size pages (e.g., 10,000 records each) identified by an offset or cursor.
2. After successfully writing each page, persist the cursor to a `checkpoints` table.
3. On restart, read the last committed cursor and resume from there.
4. Wrap each page write in a database transaction — either the whole page commits or none of it does.

**Kafka offset management**
If using Kafka, only commit the consumer offset **after** a successful DB write. A crash before the commit causes the consumer to re-read and re-process the same messages, which is safe because of the DB-level idempotency.

**At-least-once delivery + idempotent sink = exactly-once semantics** — no partial data, no duplicates, regardless of where the failure occurs.
