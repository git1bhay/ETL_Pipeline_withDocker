import logging
import os
import time
from statistics import mean

import requests
from pydantic import ValidationError

from db import init_db, log_run, upsert_records
from models import MarketRecord

# ── Structured logging ────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger("etl")

API_URL = os.environ.get("API_URL", "http://api:8000/v1/market-data")
POLL_INTERVAL = int(os.environ.get("POLL_INTERVAL_SECONDS", 10))
OUTLIER_THRESHOLD = float(os.environ.get("OUTLIER_THRESHOLD", 0.15))
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT_SECONDS", 5))
MAX_RETRIES = int(os.environ.get("MAX_RETRIES", 3))


# ── Extraction ────────────────────────────────────────────────────────────────
def fetch_data() -> list[dict] | None:
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.get(API_URL, timeout=REQUEST_TIMEOUT)
            if resp.status_code != 200:
                log.warning("API returned HTTP %s (attempt %s/%s)", resp.status_code, attempt, MAX_RETRIES)
                time.sleep(1)
                continue
            payload = resp.json()
            if not isinstance(payload, list):
                log.warning("Unexpected payload shape (attempt %s/%s): %s", attempt, MAX_RETRIES, type(payload))
                time.sleep(1)
                continue
            return payload
        except requests.exceptions.Timeout:
            log.warning("Request timed out (attempt %s/%s)", attempt, MAX_RETRIES)
        except requests.exceptions.RequestException as exc:
            log.warning("Network error (attempt %s/%s): %s", attempt, MAX_RETRIES, exc)
        time.sleep(1)

    log.error("All %s fetch attempts failed — skipping cycle", MAX_RETRIES)
    return None


# ── Validation ────────────────────────────────────────────────────────────────
def validate(raw_records: list[dict]) -> tuple[list[MarketRecord], int]:
    valid, dropped = [], 0
    for raw in raw_records:
        try:
            valid.append(MarketRecord(**raw))
        except (ValidationError, TypeError) as exc:
            dropped += 1
            log.warning("Validation failure — dropped record: %s | reason: %s", raw, exc)
    return valid, dropped


# ── Transformation ────────────────────────────────────────────────────────────
def compute_vwap(records: list[MarketRecord]) -> dict[str, float]:
    """VWAP = sum(price * volume) / sum(volume) per instrument."""
    totals: dict[str, tuple[float, float]] = {}
    for r in records:
        pv, v = totals.get(r.instrument_id, (0.0, 0.0))
        totals[r.instrument_id] = (pv + r.price * r.volume, v + r.volume)
    return {
        iid: (pv / v) if v else 0.0
        for iid, (pv, v) in totals.items()
    }


def flag_outliers(records: list[MarketRecord]) -> list[dict]:
    avg_prices: dict[str, float] = {}
    by_instrument: dict[str, list[float]] = {}
    for r in records:
        by_instrument.setdefault(r.instrument_id, []).append(r.price)
    for iid, prices in by_instrument.items():
        avg_prices[iid] = mean(prices)

    vwaps = compute_vwap(records)

    enriched = []
    for r in records:
        avg = avg_prices[r.instrument_id]
        deviation = abs(r.price - avg) / avg if avg else 0
        is_outlier = deviation > OUTLIER_THRESHOLD
        if is_outlier:
            log.warning(
                "Outlier detected — %s price=%.4f avg=%.4f deviation=%.1f%%",
                r.instrument_id, r.price, avg, deviation * 100,
            )
        enriched.append({
            "instrument_id": r.instrument_id,
            "price": float(r.price),
            "volume": float(r.volume),
            "timestamp": r.timestamp,
            "vwap": round(vwaps[r.instrument_id], 6),
            "is_outlier": is_outlier,
        })
    return enriched


# ── Pipeline loop ─────────────────────────────────────────────────────────────
def run_once():
    start = time.time()

    raw = fetch_data()
    if raw is None:
        return

    records_fetched = len(raw)
    valid_records, dropped = validate(raw)
    enriched = flag_outliers(valid_records)
    written = upsert_records(enriched)

    elapsed_ms = int((time.time() - start) * 1000)
    log.info(
        "Run complete | fetched=%d valid=%d dropped=%d written=%d time=%dms",
        records_fetched, len(valid_records), dropped, written, elapsed_ms,
    )
    log_run(records_fetched, len(valid_records), dropped, written, elapsed_ms)


def wait_for_db(retries=15, delay=3):
    from db import get_connection
    for i in range(retries):
        try:
            conn = get_connection()
            conn.close()
            log.info("Database is ready.")
            return
        except Exception as exc:
            log.info("Waiting for DB (%s/%s): %s", i + 1, retries, exc)
            time.sleep(delay)
    raise RuntimeError("Database not available after retries")


def wait_for_api(retries=15, delay=3):
    for i in range(retries):
        try:
            resp = requests.get(API_URL.replace("/v1/market-data", "/health"), timeout=3)
            if resp.status_code == 200:
                log.info("API is ready.")
                return
        except Exception as exc:
            log.info("Waiting for API (%s/%s): %s", i + 1, retries, exc)
        time.sleep(delay)
    raise RuntimeError("API not available after retries")


if __name__ == "__main__":
    log.info("ETL pipeline starting…")
    wait_for_db()
    init_db()
    wait_for_api()
    log.info("Starting poll loop every %ss", POLL_INTERVAL)
    while True:
        try:
            run_once()
        except Exception as exc:
            log.error("Unexpected error in pipeline cycle: %s", exc, exc_info=True)
        time.sleep(POLL_INTERVAL)
