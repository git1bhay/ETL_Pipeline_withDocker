import os

import psycopg2
from psycopg2.extras import execute_values


def get_connection():
    return psycopg2.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", 5432)),
        dbname=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
    )


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS market_data (
            id              SERIAL PRIMARY KEY,
            instrument_id   TEXT        NOT NULL,
            price           NUMERIC     NOT NULL,
            volume          NUMERIC     NOT NULL,
            timestamp       TIMESTAMPTZ NOT NULL,
            vwap            NUMERIC,
            is_outlier      BOOLEAN     DEFAULT FALSE,
            ingested_at     TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE (instrument_id, timestamp)
        );
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS pipeline_runs (
            id              SERIAL PRIMARY KEY,
            run_at          TIMESTAMPTZ DEFAULT NOW(),
            records_fetched INT,
            records_valid   INT,
            records_dropped INT,
            records_written INT,
            execution_ms    INT
        );
    """)

    conn.commit()
    cur.close()
    conn.close()


def upsert_records(records: list[dict]) -> int:
    """Insert records, skip duplicates. Returns count written."""
    if not records:
        return 0

    conn = get_connection()
    cur = conn.cursor()

    rows = [
        (
            r["instrument_id"],
            r["price"],
            r["volume"],
            r["timestamp"],
            r["vwap"],
            r["is_outlier"],
        )
        for r in records
    ]

    query = """
        INSERT INTO market_data (instrument_id, price, volume, timestamp, vwap, is_outlier)
        VALUES %s
        ON CONFLICT (instrument_id, timestamp) DO NOTHING
    """
    execute_values(cur, query, rows)
    written = cur.rowcount
    conn.commit()
    cur.close()
    conn.close()
    return written


def log_run(fetched: int, valid: int, dropped: int, written: int, ms: int):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO pipeline_runs (records_fetched, records_valid, records_dropped, records_written, execution_ms)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (fetched, valid, dropped, written, ms),
    )
    conn.commit()
    cur.close()
    conn.close()
