from datetime import datetime
from typing import Optional

from pydantic import BaseModel, field_validator


class MarketRecord(BaseModel):
    instrument_id: str
    price: float
    volume: float
    timestamp: datetime

    @field_validator("price")
    @classmethod
    def price_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError("price must be positive")
        return v

    @field_validator("volume")
    @classmethod
    def volume_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError("volume must be positive")
        return v

    @field_validator("instrument_id")
    @classmethod
    def instrument_id_not_empty(cls, v):
        if not v or not v.strip():
            raise ValueError("instrument_id must not be empty")
        return v.strip()
